function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6oI0OcBJODa":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

